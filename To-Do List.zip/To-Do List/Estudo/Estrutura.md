model → representa dados
(ex: Tarefa)

service → manipula esses dados
(ex: adicionar tarefa, concluir, remover)

app → interage com o usuário
(menu, Scanner, etc.)


⚡ Resumão direto

model → estrutura dos dados

service → regras e ações

app → interação com usuário

----------------------------------------------------------------------------------

package main.java.com.tdl.service;

🚀 Resumão

package = endereço da classe

Organiza o projeto

Ajuda o Java a encontrar as classes

-----------------------------------------------------------------------------------

🔹 Getter (pegar valor)

Um getter serve para retornar o valor de um atributo.

public String getNome() {
    return nome;
}

👉 Ele permite ler o valor da variável nome.



🔹 Setter (definir valor)

Um setter serve para alterar o valor de um atributo.

public void setNome(String nome) {
    this.nome = nome;
}

👉 Ele permite modificar o valor da variável nome.



🔹 Vantagens de usar getters e setters

🔒 Segurança: você controla como os dados são acessados

✅ Validação: pode validar antes de alterar (ex: não permitir idade negativa)

🔄 Flexibilidade: pode mudar a implementação sem afetar quem usa a classe

🧱 Encapsulamento: segue boas práticas de orientação a objetos


--------------------------------------------------------------------------------------

🔹 Classe (Class)

Uma classe é como um “molde” ou “planta” para criar objetos.

👉 Exemplo:

class Pessoa {
    String nome;
    int idade;
}

Aqui você definiu o que uma pessoa tem (nome e idade), mas ainda não criou nenhuma pessoa de verdade.

--------------------------------------------------------------------------------------------------------

🔹 Objeto (Object)

Um objeto é uma instância da classe, ou seja, algo criado a partir do molde.

👉 Exemplo:

Pessoa p1 = new Pessoa();
p1.nome = "João";
p1.idade = 25;

Agora você tem uma pessoa real no código.

-------------------------------------------------------------------------------------------------------------------

🔹 Método (Method)

Um método é uma função que pertence a uma classe. Ele define o que o objeto pode fazer.

👉 Exemplo:

class Pessoa {
    String nome;

    void falar() {
        System.out.println("Olá!");
    }
}

Uso:

Pessoa p1 = new Pessoa();
p1.falar();

-----------------------------------------------------------------------------------------------------------------------

🔹 Atributo (Variável)

São as características do objeto (também chamados de propriedades).

👉 Exemplo:

String nome;
int idade;

-------------------------------------------------------------------------------------------------------------------------------

🔹 Construtor (Constructor)

É um método especial usado para inicializar um objeto quando ele é criado.

👉 Exemplo:

class Pessoa {
    String nome;

    Pessoa(String nome) {
        this.nome = nome;
    }
}

Uso:

Pessoa p1 = new Pessoa("Maria");

-------------------------------------------------------------------------------------------------------------------

🔹 Encapsulamento

É proteger os dados usando private e acessar com métodos (get e set).

👉 Exemplo:

class Pessoa {
    private String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}

---------------------------------------------------------------------------------------------------------------------------

🔹 Herança (Inheritance)

Uma classe pode herdar características de outra.

👉 Exemplo:

class Animal {
    void fazerSom() {
        System.out.println("Som");
    }
}

class Cachorro extends Animal {
}

-------------------------------------------------------------------------------------------

🔹 Polimorfismo

Permite usar o mesmo método com comportamentos diferentes.