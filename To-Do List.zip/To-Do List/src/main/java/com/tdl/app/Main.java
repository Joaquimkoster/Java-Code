package main.java.com.tdl.app;

import java.util.Scanner;
import  main.java.com.tdl.*;
import main.java.com.tdl.service.TarefaServise;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TarefaServise servise =  new TarefaServise();
        int opcao  = 0;

        System.out.println("==== Bem-vindo ao Seu To-Do List ====");

        do {
            System.out.println("\n1. Adicionar Tarefa");
            System.out.println("2. Listar Tarefas");
            System.out.println("3. Remover Tarefa");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            opcao =  scanner.nextInt();
            scanner.nextLine();
        }
    }

    
}