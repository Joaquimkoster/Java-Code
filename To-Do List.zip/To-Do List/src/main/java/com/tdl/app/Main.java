package main.java.com.tdl.app;

import java.util.List;
import java.util.Scanner;
import main.java.com.tdl.service.TarefaServise;
import main.java.com.tdl.model.Tarefa;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TarefaServise servise = new TarefaServise();
        int opcao = 0;

        System.out.println("==== Bem-vindo ao Seu To-Do List ====");

        do {
            System.out.println("\n1. Adicionar Tarefa");
            System.out.println("2. Listar Tarefas");
            System.out.println("3. Remover Tarefa");
            System.out.println("4. Concluir Tarefa");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            try {
                opcao = scanner.nextInt();
                scanner.nextLine();
            } catch (Exception e) {
                System.out.println("Digite apenas numeros de 0 a 4!!");
                scanner.nextLine();
                opcao = -1;
            }

            switch (opcao) {
                case 1:
                    System.out.println("Digite o nome da tarefa: ");
                    String titulo = scanner.nextLine();
                    Tarefa novaTarefa = new Tarefa(titulo, false, "20/05/2026");
                    servise.adicionarTarefa(novaTarefa);
                    break;

                case 2:
                    System.out.println("\n=== Lista De Tarefas");
                    List<Tarefa> tarefas = servise.listarTodas();

                    if (tarefas.isEmpty()) {
                        System.out.println("Nenhuma Tarefa Cadastrada ainda!");
                    } else {
                        for (int i = 0; i < tarefas.size(); i++) {
                            Tarefa t = tarefas.get(i);
                            String status = t.getconcluida() ? "[x]" : "[ ]";
                            System.out.println(i + " - " + status + " " + t.getdescricao());
                        }
                    }
                    break;

                case 3:
                    int index = -1;
                    try {
                        System.out.println("Digite o indice da tarefa que deseja remover: ");
                        index = scanner.nextInt();
                        scanner.nextLine();

                        boolean removido = servise.removerTarefa(index);
                        if (removido) {
                            System.out.println("Tarefa removida com sucesso!");
                        }
                    } catch (Exception e) {
                        System.out.println("Digite apenas números!!");
                        scanner.nextLine();
                    }
                    break;

                case 4:
                    try {
                        System.out.println("Digite o indice da tarefa que deseja concluir: ");
                        int indexConcluir = scanner.nextInt();
                        scanner.nextLine(); 

                        servise.marcarComoconcluida(indexConcluir);
                    } catch (Exception e) {
                        System.out.println("Entrada inválida!");
                        scanner.nextLine();
                    }
                    break;

            }

        } while (opcao != 0);
        System.out.println("Programa encerrado");
        scanner.close();
    }

}