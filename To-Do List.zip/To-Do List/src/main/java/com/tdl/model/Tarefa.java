package main.java.com.tdl.model;

public class Tarefa {

    // Define Atributos

    private String descricao;
    private Boolean concluida;
    private int prioridade;
    private String datacriacao;

    // Construtor

    public Tarefa(String descricao, Boolean concluida, int prioridade, String datacriacao) {
        this.descricao = descricao;
        this.concluida = concluida;
        this.prioridade = prioridade;
        this.datacriacao = datacriacao;
    }

    // Getters

    public String getdescricao() {
        return descricao;
    }

    public Boolean getconcluida() {
        return concluida;
    }

    public int getprioridade() {
        return prioridade;
    }

    public String getdatacriacao() {
        return datacriacao;
    }

    // Setters

    public void setdescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setconcluida(boolean concluida) {
        this.concluida = concluida;
    }

    public void setprioridade(int prioridade) {
        this.prioridade = prioridade;
    }

    public void setdatacriacao(String datacriacao) {
        this.datacriacao = datacriacao;
    }
}