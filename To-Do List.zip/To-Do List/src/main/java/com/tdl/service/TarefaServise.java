package main.java.com.tdl.service;

import java.util.ArrayList;
import java.util.List;
import main.java.com.tdl.model.Tarefa;

public class TarefaServise {

    // Esta lista armazenará todas as suas tarefas

    private List<Tarefa> listaDeTarefas = new ArrayList<>();

    // Método para adicionar uma nova tarefa

    public void adicionarTarefa(Tarefa tarefa) {
        listaDeTarefas.add(tarefa);
        System.out.println("Tarefa adicionada com sucesso!");
    }

    // Método para retornar todas as tarefas
    public List<Tarefa> listarTodas() {
        return listaDeTarefas;
    }

    // Método para remover (por índice)
    public void removerTarefa(int index) {
        if (index >= 0 && index < listaDeTarefas.size()) {
            listaDeTarefas.remove(index);
        } else {
            System.out.println("Índice inválido!");
        }
    }

}